library(testthat)
library(PesticideLoadIndicator)

test_check("PesticideLoadIndicator")
