# PesticideLoadIndicator

The goal of PesticideLoadIndicator is to ...

## Installation

You can install the released version of PesticideLoadIndicator from [CRAN](https://CRAN.R-project.org) with:

``` r
install.packages("PesticideLoadIndicator")
```

## Example

This is a basic example which shows you how to solve a common problem:

``` r
library(PesticideLoadIndicator)
## basic example code
```

